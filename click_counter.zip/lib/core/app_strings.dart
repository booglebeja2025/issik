/// All user-facing texts, kept in one place for easy maintenance and
/// future localisation.
abstract final class AppStrings {
  static const String appTitle = 'Click Counter';
  static const String pageTitle = 'Click Counter';

  // Counter
  static String ofGoal(int goal) => 'of $goal clicks';
  static String toGo(int remaining) => '$remaining to go';
  static String semanticsCounter(int count, int goal) =>
      '$count of $goal clicks';
  static const String goalReached = 'Goal reached';
  static String goalReachedMessage(int goal) =>
      'Goal of $goal reached. Great job!';

  // Stats
  static const String statBest = 'Best';
  static const String statGoal = 'Goal';
  static const String statProgress = 'Progress';

  // Actions
  static const String increment = 'Add a click';
  static const String decrement = 'Decrement';
  static const String reset = 'Reset';
  static const String counterReset = 'Counter reset';
  static const String undo = 'Undo';

  // Settings
  static const String settings = 'Settings';
  static const String appearance = 'Appearance';
  static const String themeAuto = 'Auto';
  static const String themeLight = 'Light';
  static const String themeDark = 'Dark';
  static const String goalSetting = 'Click goal';
  static const String haptics = 'Haptic feedback';
  static const String hapticsSubtitle = 'Vibrate slightly on each tap';
}
