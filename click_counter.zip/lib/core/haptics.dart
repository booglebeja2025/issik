import 'dart:async';

import 'package:flutter/services.dart';

/// Thin wrapper around [HapticFeedback] that honours the user setting.
abstract final class Haptics {
  static void tap({required bool enabled}) {
    if (enabled) unawaited(HapticFeedback.selectionClick());
  }

  static void success({required bool enabled}) {
    if (enabled) unawaited(HapticFeedback.heavyImpact());
  }
}
