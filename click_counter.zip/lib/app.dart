import 'package:flutter/material.dart';

import 'core/app_strings.dart';
import 'core/app_theme.dart';
import 'features/counter/counter_controller.dart';
import 'features/counter/counter_page.dart';
import 'features/settings/settings_controller.dart';

/// Root widget: wires the theme, the settings and the home page together.
class App extends StatelessWidget {
  const App({super.key, required this.settings, required this.counter});

  final SettingsController settings;
  final CounterController counter;

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: settings,
      builder: (context, _) => MaterialApp(
        title: AppStrings.appTitle,
        debugShowCheckedModeBanner: false,
        theme: AppTheme.light,
        darkTheme: AppTheme.dark,
        themeMode: settings.themeMode,
        home: CounterPage(counter: counter, settings: settings),
      ),
    );
  }
}
