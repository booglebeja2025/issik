import 'package:flutter/material.dart';

import '../../core/app_strings.dart';
import '../counter/counter_controller.dart';
import 'settings_controller.dart';

/// Opens the settings bottom sheet.
Future<void> showSettingsSheet(
  BuildContext context, {
  required SettingsController settings,
  required CounterController counter,
}) {
  return showModalBottomSheet<void>(
    context: context,
    showDragHandle: true,
    isScrollControlled: true,
    builder: (context) => _SettingsSheet(settings: settings, counter: counter),
  );
}

class _SettingsSheet extends StatelessWidget {
  const _SettingsSheet({required this.settings, required this.counter});

  final SettingsController settings;
  final CounterController counter;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final sectionStyle = theme.textTheme.titleSmall?.copyWith(
      color: theme.colorScheme.primary,
      fontWeight: FontWeight.w600,
    );

    return SafeArea(
      child: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(24, 0, 24, 24),
        child: ListenableBuilder(
          listenable: Listenable.merge(<Listenable>[settings, counter]),
          builder: (context, _) => Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Text(AppStrings.settings, style: theme.textTheme.headlineSmall),
              const SizedBox(height: 24),
              Text(AppStrings.appearance, style: sectionStyle),
              const SizedBox(height: 12),
              SizedBox(
                width: double.infinity,
                child: SegmentedButton<ThemeMode>(
                  showSelectedIcon: false,
                  segments: const <ButtonSegment<ThemeMode>>[
                    ButtonSegment<ThemeMode>(
                      value: ThemeMode.system,
                      icon: Icon(Icons.brightness_auto_outlined),
                      label: Text(AppStrings.themeAuto),
                    ),
                    ButtonSegment<ThemeMode>(
                      value: ThemeMode.light,
                      icon: Icon(Icons.light_mode_outlined),
                      label: Text(AppStrings.themeLight),
                    ),
                    ButtonSegment<ThemeMode>(
                      value: ThemeMode.dark,
                      icon: Icon(Icons.dark_mode_outlined),
                      label: Text(AppStrings.themeDark),
                    ),
                  ],
                  selected: <ThemeMode>{settings.themeMode},
                  onSelectionChanged: (selection) =>
                      settings.setThemeMode(selection.first),
                ),
              ),
              const SizedBox(height: 28),
              Row(
                children: <Widget>[
                  Expanded(
                    child: Text(AppStrings.goalSetting, style: sectionStyle),
                  ),
                  Text(
                    '${counter.goal}',
                    style: theme.textTheme.titleMedium?.copyWith(
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ],
              ),
              Slider(
                value: counter.goal.toDouble(),
                min: CounterController.minGoal.toDouble(),
                max: CounterController.maxGoal.toDouble(),
                divisions:
                    (CounterController.maxGoal - CounterController.minGoal) ~/
                        10,
                label: '${counter.goal}',
                onChanged: (value) => counter.setGoal(value.round()),
              ),
              const SizedBox(height: 12),
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                title: const Text(AppStrings.haptics),
                subtitle: const Text(AppStrings.hapticsSubtitle),
                value: settings.hapticsEnabled,
                onChanged: (value) =>
                    settings.setHapticsEnabled(value: value),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
