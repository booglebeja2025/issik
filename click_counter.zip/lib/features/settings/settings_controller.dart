import 'dart:async';

import 'package:flutter/material.dart';

import '../../data/app_storage.dart';

/// User preferences (theme, haptics), persisted on the device.
class SettingsController extends ChangeNotifier {
  SettingsController(AppStorage storage)
      : _storage = storage,
        _themeMode = storage.themeMode,
        _hapticsEnabled = storage.hapticsEnabled;

  final AppStorage _storage;
  ThemeMode _themeMode;
  bool _hapticsEnabled;

  ThemeMode get themeMode => _themeMode;
  bool get hapticsEnabled => _hapticsEnabled;

  void setThemeMode(ThemeMode mode) {
    if (mode == _themeMode) return;
    _themeMode = mode;
    unawaited(_storage.saveThemeMode(mode));
    notifyListeners();
  }

  void setHapticsEnabled({required bool value}) {
    if (value == _hapticsEnabled) return;
    _hapticsEnabled = value;
    unawaited(_storage.saveHapticsEnabled(value: value));
    notifyListeners();
  }
}
