import 'dart:async';

import 'package:flutter/foundation.dart';

import '../../data/app_storage.dart';

/// Holds the counter state, persists it and notifies listeners.
///
/// Kept free of any UI code so it can be unit-tested on its own.
class CounterController extends ChangeNotifier {
  CounterController(AppStorage storage)
      : _storage = storage,
        _count = storage.count.clamp(0, maxCount).toInt(),
        _best = storage.best,
        _goal = _sanitizeGoal(storage.goal ?? defaultGoal);

  static const int minGoal = 10;
  static const int maxGoal = 500;
  static const int defaultGoal = 100;
  static const int maxCount = 999999;

  final AppStorage _storage;
  int _count;
  int _best;
  int _goal;

  int get count => _count;
  int get best => _best;
  int get goal => _goal;
  int get remaining => (_goal - _count).clamp(0, _goal).toInt();
  bool get goalReached => _count >= _goal;
  double get progress => (_count / _goal).clamp(0.0, 1.0).toDouble();

  static int _sanitizeGoal(int value) => value.clamp(minGoal, maxGoal).toInt();

  /// Adds one click. Returns `true` when this click made the goal reached.
  bool increment() {
    if (_count >= maxCount) return false;
    final wasReached = goalReached;
    _count++;
    _updateBest();
    _persist();
    notifyListeners();
    return !wasReached && goalReached;
  }

  void decrement() {
    if (_count == 0) return;
    _count--;
    _persist();
    notifyListeners();
  }

  /// Sets the counter back to zero and returns the previous value so the
  /// caller can offer an "undo".
  int reset() {
    final previous = _count;
    if (previous == 0) return 0;
    _count = 0;
    _persist();
    notifyListeners();
    return previous;
  }

  void restore(int value) {
    _count = value.clamp(0, maxCount).toInt();
    _updateBest();
    _persist();
    notifyListeners();
  }

  void setGoal(int value) {
    final sanitized = _sanitizeGoal(value);
    if (sanitized == _goal) return;
    _goal = sanitized;
    unawaited(_storage.saveGoal(_goal));
    notifyListeners();
  }

  void _updateBest() {
    if (_count > _best) {
      _best = _count;
      unawaited(_storage.saveBest(_best));
    }
  }

  void _persist() => unawaited(_storage.saveCount(_count));
}
