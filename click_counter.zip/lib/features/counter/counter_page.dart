import 'dart:async';

import 'package:flutter/material.dart';

import '../../core/app_strings.dart';
import '../../core/haptics.dart';
import '../settings/settings_controller.dart';
import '../settings/settings_sheet.dart';
import 'counter_controller.dart';
import 'widgets/progress_ring.dart';
import 'widgets/stat_tile.dart';

/// Home screen: progress ring, statistics and quick actions.
class CounterPage extends StatelessWidget {
  const CounterPage({
    super.key,
    required this.counter,
    required this.settings,
  });

  final CounterController counter;
  final SettingsController settings;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(AppStrings.pageTitle),
        actions: <Widget>[
          IconButton(
            tooltip: AppStrings.settings,
            icon: const Icon(Icons.tune_rounded),
            onPressed: () => _openSettings(context),
          ),
        ],
      ),
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.fromLTRB(24, 16, 24, 128),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 480),
              child: ListenableBuilder(
                listenable: counter,
                builder: (context, _) => _buildContent(context),
              ),
            ),
          ),
        ),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerFloat,
      floatingActionButton: FloatingActionButton.large(
        onPressed: () => _increment(context),
        tooltip: AppStrings.increment,
        child: const Icon(Icons.add_rounded, size: 40),
      ),
    );
  }

  Widget _buildContent(BuildContext context) {
    final hasClicks = counter.count > 0;

    return Column(
      mainAxisSize: MainAxisSize.min,
      children: <Widget>[
        Semantics(
          liveRegion: true,
          label: AppStrings.semanticsCounter(counter.count, counter.goal),
          child: ExcludeSemantics(
            child: ProgressRing(
              progress: counter.progress,
              reached: counter.goalReached,
              child: _CounterValue(count: counter.count, goal: counter.goal),
            ),
          ),
        ),
        const SizedBox(height: 24),
        AnimatedSwitcher(
          duration: const Duration(milliseconds: 250),
          child: counter.goalReached
              ? const _StatusPill(
                  key: ValueKey<String>('reached'),
                  icon: Icons.emoji_events_rounded,
                  label: AppStrings.goalReached,
                  highlighted: true,
                )
              : _StatusPill(
                  key: const ValueKey<String>('remaining'),
                  icon: Icons.flag_outlined,
                  label: AppStrings.toGo(counter.remaining),
                ),
        ),
        const SizedBox(height: 32),
        Row(
          children: <Widget>[
            Expanded(
              child: StatTile(
                icon: Icons.emoji_events_outlined,
                label: AppStrings.statBest,
                value: '${counter.best}',
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: StatTile(
                icon: Icons.flag_outlined,
                label: AppStrings.statGoal,
                value: '${counter.goal}',
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: StatTile(
                icon: Icons.donut_large_rounded,
                label: AppStrings.statProgress,
                value: '${(counter.progress * 100).round()}%',
              ),
            ),
          ],
        ),
        const SizedBox(height: 24),
        Row(
          children: <Widget>[
            Expanded(
              child: OutlinedButton.icon(
                style: OutlinedButton.styleFrom(
                  minimumSize: const Size(0, 52),
                ),
                onPressed: hasClicks ? () => _decrement(context) : null,
                icon: const Icon(Icons.remove_rounded),
                label: const Text(AppStrings.decrement),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: OutlinedButton.icon(
                style: OutlinedButton.styleFrom(
                  minimumSize: const Size(0, 52),
                ),
                onPressed: hasClicks ? () => _reset(context) : null,
                icon: const Icon(Icons.restart_alt_rounded),
                label: const Text(AppStrings.reset),
              ),
            ),
          ],
        ),
      ],
    );
  }

  void _increment(BuildContext context) {
    final reachedGoal = counter.increment();
    if (reachedGoal) {
      Haptics.success(enabled: settings.hapticsEnabled);
      _showMessage(context, AppStrings.goalReachedMessage(counter.goal));
    } else {
      Haptics.tap(enabled: settings.hapticsEnabled);
    }
  }

  void _decrement(BuildContext context) {
    counter.decrement();
    Haptics.tap(enabled: settings.hapticsEnabled);
  }

  void _reset(BuildContext context) {
    final previous = counter.reset();
    if (previous == 0) return;
    Haptics.tap(enabled: settings.hapticsEnabled);
    _showMessage(
      context,
      AppStrings.counterReset,
      action: SnackBarAction(
        label: AppStrings.undo,
        onPressed: () => counter.restore(previous),
      ),
    );
  }

  void _openSettings(BuildContext context) {
    unawaited(
      showSettingsSheet(context, settings: settings, counter: counter),
    );
  }

  void _showMessage(
    BuildContext context,
    String message, {
    SnackBarAction? action,
  }) {
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(message), action: action));
  }
}

class _CounterValue extends StatelessWidget {
  const _CounterValue({required this.count, required this.goal});

  final int count;
  final int goal;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Column(
      mainAxisSize: MainAxisSize.min,
      children: <Widget>[
        SizedBox(
          width: 168,
          child: FittedBox(
            fit: BoxFit.scaleDown,
            child: AnimatedSwitcher(
              duration: const Duration(milliseconds: 220),
              transitionBuilder: (child, animation) => ScaleTransition(
                scale: animation,
                child: FadeTransition(opacity: animation, child: child),
              ),
              child: Text(
                '$count',
                key: ValueKey<int>(count),
                style: theme.textTheme.displayLarge?.copyWith(
                  fontWeight: FontWeight.w700,
                  height: 1.1,
                ),
              ),
            ),
          ),
        ),
        Text(
          AppStrings.ofGoal(goal),
          style: theme.textTheme.bodyMedium?.copyWith(
            color: theme.colorScheme.onSurfaceVariant,
          ),
        ),
      ],
    );
  }
}

class _StatusPill extends StatelessWidget {
  const _StatusPill({
    super.key,
    required this.icon,
    required this.label,
    this.highlighted = false,
  });

  final IconData icon;
  final String label;
  final bool highlighted;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final scheme = theme.colorScheme;
    final background =
        highlighted ? scheme.tertiaryContainer : scheme.secondaryContainer;
    final foreground = highlighted
        ? scheme.onTertiaryContainer
        : scheme.onSecondaryContainer;

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      decoration: BoxDecoration(
        color: background,
        borderRadius: BorderRadius.circular(999),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          Icon(icon, size: 18, color: foreground),
          const SizedBox(width: 8),
          Text(
            label,
            style: theme.textTheme.labelLarge?.copyWith(color: foreground),
          ),
        ],
      ),
    );
  }
}
