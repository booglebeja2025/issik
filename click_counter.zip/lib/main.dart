import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'app.dart';
import 'data/app_storage.dart';
import 'features/counter/counter_controller.dart';
import 'features/settings/settings_controller.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  final storage = AppStorage(await SharedPreferences.getInstance());

  runApp(
    App(
      settings: SettingsController(storage),
      counter: CounterController(storage),
    ),
  );
}
