import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// Typed access to everything persisted on the device.
class AppStorage {
  AppStorage(this._prefs);

  final SharedPreferences _prefs;

  static const String _countKey = 'counter.count';
  static const String _bestKey = 'counter.best';
  static const String _goalKey = 'counter.goal';
  static const String _themeKey = 'settings.theme_mode';
  static const String _hapticsKey = 'settings.haptics';

  int get count => _prefs.getInt(_countKey) ?? 0;
  int get best => _prefs.getInt(_bestKey) ?? 0;
  int? get goal => _prefs.getInt(_goalKey);

  ThemeMode get themeMode {
    final name = _prefs.getString(_themeKey);
    return ThemeMode.values.firstWhere(
      (mode) => mode.name == name,
      orElse: () => ThemeMode.system,
    );
  }

  bool get hapticsEnabled => _prefs.getBool(_hapticsKey) ?? true;

  Future<void> saveCount(int value) => _prefs.setInt(_countKey, value);
  Future<void> saveBest(int value) => _prefs.setInt(_bestKey, value);
  Future<void> saveGoal(int value) => _prefs.setInt(_goalKey, value);
  Future<void> saveThemeMode(ThemeMode mode) =>
      _prefs.setString(_themeKey, mode.name);
  Future<void> saveHapticsEnabled({required bool value}) =>
      _prefs.setBool(_hapticsKey, value);
}
