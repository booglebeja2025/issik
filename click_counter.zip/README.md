# Click Counter

A polished Flutter click counter: animated progress ring, goal tracking,
statistics, undo, light/dark theme, haptic feedback and persistent storage.

## Open in Android Studio

1. Install the **Flutter** and **Dart** plugins (Settings → Plugins).
2. **File → Open…** and select this folder (the one containing `pubspec.yaml`).
3. Click **Pub get** in the banner (or run `flutter pub get`). This also creates
   `android/local.properties` with your Flutter SDK path.
4. Pick an emulator or a phone and run the **main.dart** configuration.

Requirements: Flutter 3.24+ (Dart 3.5+), JDK 17+ (the one bundled with Android
Studio works).

## Structure

```
lib/
├── main.dart                     # Entry point
├── app.dart                      # MaterialApp, theme mode
├── core/                         # Theme, strings, haptics
├── data/app_storage.dart         # SharedPreferences wrapper
└── features/
    ├── counter/                  # Controller, page, ring & stat widgets
    └── settings/                 # Controller + bottom sheet
test/                             # Unit + widget tests
```

## Quality checks

```bash
flutter analyze
flutter test
```

## Release build (Android)

Create `android/key.properties` (never commit it):

```
keyAlias=upload
keyPassword=...
storeFile=/path/to/upload-keystore.jks
storePassword=...
```

then run `flutter build appbundle --release`.

## Before publishing

The application id is `com.clickcounter.app`. Replace it with your own in
`android/app/build.gradle.kts` (namespace + applicationId), move
`MainActivity.kt` to the matching package folder, and update
`PRODUCT_BUNDLE_IDENTIFIER` in `ios/Runner.xcodeproj/project.pbxproj`.
