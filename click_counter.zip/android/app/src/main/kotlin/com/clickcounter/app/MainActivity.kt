package com.clickcounter.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
