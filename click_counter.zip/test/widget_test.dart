import 'package:click_counter/app.dart';
import 'package:click_counter/core/app_strings.dart';
import 'package:click_counter/data/app_storage.dart';
import 'package:click_counter/features/counter/counter_controller.dart';
import 'package:click_counter/features/counter/widgets/progress_ring.dart';
import 'package:click_counter/features/settings/settings_controller.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  testWidgets('increment, decrement and reset with undo', (tester) async {
    tester.view.physicalSize = const Size(1080, 2400);
    tester.view.devicePixelRatio = 3;
    addTearDown(tester.view.reset);

    SharedPreferences.setMockInitialValues(<String, Object>{});
    final storage = AppStorage(await SharedPreferences.getInstance());

    await tester.pumpWidget(
      App(
        settings: SettingsController(storage),
        counter: CounterController(storage),
      ),
    );
    await tester.pumpAndSettle();

    Finder ringValue(String text) => find.descendant(
          of: find.byType(ProgressRing),
          matching: find.text(text),
        );

    expect(find.text(AppStrings.pageTitle), findsOneWidget);
    expect(ringValue('0'), findsOneWidget);

    await tester.tap(find.byType(FloatingActionButton));
    await tester.pumpAndSettle();
    await tester.tap(find.byType(FloatingActionButton));
    await tester.pumpAndSettle();
    expect(ringValue('2'), findsOneWidget);

    await tester.tap(find.text(AppStrings.decrement));
    await tester.pumpAndSettle();
    expect(ringValue('1'), findsOneWidget);

    await tester.tap(find.text(AppStrings.reset));
    await tester.pumpAndSettle();
    expect(ringValue('0'), findsOneWidget);
    expect(find.text(AppStrings.counterReset), findsOneWidget);

    await tester.tap(find.text(AppStrings.undo));
    await tester.pumpAndSettle();
    expect(ringValue('1'), findsOneWidget);
  });
}
