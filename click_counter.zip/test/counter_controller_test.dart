import 'package:click_counter/data/app_storage.dart';
import 'package:click_counter/features/counter/counter_controller.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';

Future<AppStorage> _storage() async {
  SharedPreferences.setMockInitialValues(<String, Object>{});
  return AppStorage(await SharedPreferences.getInstance());
}

void main() {
  group('CounterController', () {
    test('starts at zero with the default goal', () async {
      final controller = CounterController(await _storage());

      expect(controller.count, 0);
      expect(controller.best, 0);
      expect(controller.goal, CounterController.defaultGoal);
      expect(controller.progress, 0);
    });

    test('increment updates count, best and notifies listeners', () async {
      final controller = CounterController(await _storage());
      var notifications = 0;
      controller.addListener(() => notifications++);

      controller
        ..increment()
        ..increment();

      expect(controller.count, 2);
      expect(controller.best, 2);
      expect(notifications, 2);
    });

    test('decrement never goes below zero', () async {
      final controller = CounterController(await _storage())
        ..increment()
        ..decrement()
        ..decrement();

      expect(controller.count, 0);
    });

    test('increment reports the click that reaches the goal', () async {
      final controller = CounterController(await _storage())
        ..setGoal(CounterController.minGoal);

      for (var i = 1; i < CounterController.minGoal; i++) {
        expect(controller.increment(), isFalse);
      }
      expect(controller.increment(), isTrue);
      expect(controller.goalReached, isTrue);
      expect(controller.increment(), isFalse);
    });

    test('reset returns the previous value and restore brings it back',
        () async {
      final controller = CounterController(await _storage())
        ..increment()
        ..increment()
        ..increment();

      final previous = controller.reset();
      expect(previous, 3);
      expect(controller.count, 0);
      expect(controller.best, 3);

      controller.restore(previous);
      expect(controller.count, 3);
    });

    test('goal is clamped to the allowed range', () async {
      final controller = CounterController(await _storage());

      controller.setGoal(1);
      expect(controller.goal, CounterController.minGoal);

      controller.setGoal(99999);
      expect(controller.goal, CounterController.maxGoal);
    });

    test('state survives a restart', () async {
      final storage = await _storage();
      CounterController(storage)
        ..setGoal(250)
        ..increment()
        ..increment();

      final restored = CounterController(storage);

      expect(restored.count, 2);
      expect(restored.best, 2);
      expect(restored.goal, 250);
    });
  });
}
