import 'package:click_counter/data/app_storage.dart';
import 'package:click_counter/features/settings/settings_controller.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';

Future<AppStorage> _storage() async {
  SharedPreferences.setMockInitialValues(<String, Object>{});
  return AppStorage(await SharedPreferences.getInstance());
}

void main() {
  group('SettingsController', () {
    test('has sensible defaults', () async {
      final settings = SettingsController(await _storage());

      expect(settings.themeMode, ThemeMode.system);
      expect(settings.hapticsEnabled, isTrue);
    });

    test('persists theme mode and haptics', () async {
      final storage = await _storage();
      SettingsController(storage)
        ..setThemeMode(ThemeMode.dark)
        ..setHapticsEnabled(value: false);

      final restored = SettingsController(storage);

      expect(restored.themeMode, ThemeMode.dark);
      expect(restored.hapticsEnabled, isFalse);
    });
  });
}
